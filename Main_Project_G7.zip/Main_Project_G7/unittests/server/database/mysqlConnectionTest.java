package server.database;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import server.database.mysqlConnection;

class mysqlConnectionTest {

	String query;

	/*
	 * connecting to the database before queries are sent
	 */
	@BeforeEach
	void setUp() throws Exception {
		mysqlConnection.connectToDB(false);
	}

	/*
	 * checking that in the database, the returned value is indeed 3
	 */
	@Test
	void check_fuelprice_is_3() {
		query = "SELECT price FROM fuels WHERE fuelType = 4";
		Float result = (Float) (mysqlConnection.executeQuary(query).get(0).get(0));
		assertEquals(3.0, result.floatValue());
	}

	/*
	 * creating an order. then we check that the order is indeed saved, then deleting
	 * and checking if the order has been deleted successfully from the database
	 */
	@Test
	void check_order1000_details() {
		mysqlConnection.updateQuary(
				"INSERT INTO order_home_fuel(homeOrderTag, userID, orderDate, supplyDate, price, urgent, address, quantity) VALUES (1000,44,\"2020/06/26\",\"2020/07/01\",300,\"NO\",\"Karmiel\",100)");
		query = "SELECT * FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1000";
		ArrayList<ArrayList<Object>> row;
		row = mysqlConnection.executeQuary(query);
		Integer userID = (Integer) (row.get(0).get(1));
		String orderDate = (String) (row.get(0).get(2));
		String supplyDate = (String) (row.get(0).get(3));
		Float price = (Float) (row.get(0).get(4));
		String status = (String) (row.get(0).get(5));
		String urgent = (String) (row.get(0).get(6));
		String address = (String) (row.get(0).get(7));
		Float quantity = (Float) (row.get(0).get(8));
		assertEquals(userID, 44);
		assertEquals(orderDate, "2020/06/26");
		assertEquals(supplyDate, "2020/07/01");
		assertEquals(price.floatValue(), 300);
		assertEquals(status, "Not delivered");
		assertEquals(urgent, "NO");
		assertEquals(address, "Karmiel");
		assertEquals(quantity, 100);
		query = "DELETE FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1000";
		mysqlConnection.updateQuary(query);
		query = "SELECT * FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1000";
		row = mysqlConnection.executeQuary(query);
		assertNull(row);
	}

	/*
	 * creating an order. then we check that the order is indeed saved, then deleting
	 * and checking if the order has been deleted successfully from the database
	 */
	@Test
	void check_order1001_details() {
		mysqlConnection.updateQuary(
				"INSERT INTO order_home_fuel(homeOrderTag, userID, orderDate, supplyDate, price, status, urgent, address, quantity) VALUES (1001,44,\"2020/06/26\",\"2020/07/01\",2522.0,\"Delivered\",\"NO\",\"Karmiel\",650)");
		query = "SELECT * FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1001";
		ArrayList<ArrayList<Object>> row;
		row = mysqlConnection.executeQuary(query);
		Integer userID = (Integer) (row.get(0).get(1));
		String orderDate = (String) (row.get(0).get(2));
		String supplyDate = (String) (row.get(0).get(3));
		Float price = (Float) (row.get(0).get(4));
		String status = (String) (row.get(0).get(5));
		String urgent = (String) (row.get(0).get(6));
		String address = (String) (row.get(0).get(7));
		Float quantity = (Float) (row.get(0).get(8));
		assertEquals(userID, 44);
		assertEquals(orderDate, "2020/06/26");
		assertEquals(supplyDate, "2020/07/01");
		assertEquals(price.floatValue(), 2522.0);
		assertEquals(status, "Delivered");
		assertEquals(urgent, "NO");
		assertEquals(address, "Karmiel");
		assertEquals(quantity, 650);
		query = "DELETE FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1001";
		mysqlConnection.updateQuary(query);
		query = "SELECT * FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1001";
		row = mysqlConnection.executeQuary(query);
		assertNull(row);
	}

	/*
	 * creating an order. then we check that the order is indeed saved, then deleting
	 * and checking if the order has been deleted successfully from the database
	 */
	@Test
	void check_order1002_details() {
		mysqlConnection.updateQuary(
				"INSERT INTO order_home_fuel(homeOrderTag, userID, orderDate, supplyDate, price, urgent, address, quantity) VALUES (1002,44,\"2020/06/26\",\"2020/07/01\",4259.0,\"YES\",\"Karmiel\",870)");
		query = "SELECT * FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1002";
		ArrayList<ArrayList<Object>> row;
		row = mysqlConnection.executeQuary(query);
		Integer userID = (Integer) (row.get(0).get(1));
		String orderDate = (String) (row.get(0).get(2));
		String supplyDate = (String) (row.get(0).get(3));
		Float price = (Float) (row.get(0).get(4));
		String status = (String) (row.get(0).get(5));
		String urgent = (String) (row.get(0).get(6));
		String address = (String) (row.get(0).get(7));
		Float quantity = (Float) (row.get(0).get(8));
		assertEquals(userID, 44);
		assertEquals(orderDate, "2020/06/26");
		assertEquals(supplyDate, "2020/07/01");
		assertEquals(price.floatValue(), 4259.0);
		assertEquals(status, "Not delivered");
		assertEquals(urgent, "YES");
		assertEquals(address, "Karmiel");
		assertEquals(quantity, 870);
		query = "DELETE FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1002";
		mysqlConnection.updateQuary(query);
		query = "SELECT * FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1002";
		row = mysqlConnection.executeQuary(query);
		assertNull(row);
	}

	/*
	 * checking that when an order that doesnt exist is requested, the database
	 * sends null
	 */
	@Test
	void check_order_not_exist() {
		query = "SELECT * FROM order_home_fuel WHERE order_home_fuel.homeOrderTag = 1003";
		ArrayList<ArrayList<Object>> row;
		row = mysqlConnection.executeQuary(query);
		assertNull(row);
	}
}
