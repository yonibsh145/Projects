package client.common.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import client.common.controllers.CustomerOrdersHomefuelorderController;

class CustomerOrdersHomefuelorderControllerTest {

	CustomerOrdersHomefuelorderController controller;

	/*
	 * creating an instance of the requsted controller to check
	 */
	@BeforeEach
	void setUp() throws Exception {
		controller = new CustomerOrdersHomefuelorderController();
	}

	/*
	 * checking the price of urgent order with no discounts
	 */
	@Test
	void urgent_100Liters_fuelPrice3_test() {
		assertEquals(306.0,controller.calculate_price(true, 100, 3));
	}
	
	/*
	 * checking the price of non-urgent order with 3% discount
	 */
	@Test
	void Noturgent_650Liters_fuelPrice4_test() {
		assertEquals(2522.0,controller.calculate_price(false, 650, 4));
	}
	
	/*
	 * checking the price of urgent order with 4% discount
	 */
	@Test
	void urgent_870Liters_fuelPrice5_test() {
		assertEquals(4259.0,controller.calculate_price(true, 870, 5));
	}
	
	/*
	 * checking if a negetive amount is typed, then the price will be zero
	 */
	@Test
	void check_negetive_quantity() {
		assertEquals(0.0,controller.calculate_price(true, -1, 5));
	}
	
	/*
	 * checking if negetive price for liter is inputed, then the price will be zero
	 */
	@Test
	void check_negetive_price() {
		assertEquals(0.0,controller.calculate_price(true, 100, -1));
	}
	
	/*
	 * checks if a zero amount of fuel is typed, then the price will be zero
	 */
	@Test
	void check_zero_quantity() {
		assertEquals(0.0,controller.calculate_price(true, 0, 5));
	}
}
