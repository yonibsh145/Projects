package server.common;

/**
 * this is an enum class for the users positionns
 * 
 * @author henco
 * @version 1.0
 */
public enum Positions {
	CEO, SUPPLIER, MARKETING_MANAGER, MARKETING_AGENT, STATION_MANAGER;

	/**
	 * this method gets the position number and returns the position name`
	 * 
	 * @param num the position number
	 * @return the position name
	 */
	public static String getPositionName(Integer num) {
		switch (num) {
		case 1:
			return "Station Manager";
		case 2:
			return "Marketing Agent";
		case 4:
			return "CEO";
		case 5:
			return "Supplier";
		case 6:
			return "Marketing Manager";
		default:
			break;
		}
		try {
			throw new Exception("Position type error");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Error";
	}
}
