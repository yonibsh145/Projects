package server.common;

import message_info.Message;
import ocsf.server.*;
import server.common.controllers.MainServerController;

/**
 * this class is the implementation of the server side. here we will communicate
 * with the clients
 * 
 * @author henco
 * @version 1.0
 */
public class EchoServer extends AbstractServer {

	/**
	 * this method is a simple constractor from the abstract server used in ocsf
	 * 
	 * @param port of the server
	 */
	public EchoServer(int port) {
		super(port);
	}

	/**
	 * this method activates when the server recives a message
	 */
	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
		Message message = (Message) msg;
		MessageHandlerServer.HandleMessage(message, client); // lets this class handle the message
		// server displays this message
		MainServerController.instance.add_Line("From: " + client.getInetAddress() + " " + msg.toString());
	}

	/**
	 * this method handles when a client disconnects.
	 * 
	 * @param client the client disconnected
	 */
	synchronized protected void clientDisconnected(ConnectionToClient client) {
		MainServerController.instance.add_Line("From: " + client.getInetAddress() + " Disconnected");
	}

	/**
	 * Hook method called each time an exception is thrown in a ConnectionToClient
	 * thread.
	 *
	 * @param client    the client that raised the exception.
	 * @param exception the exception thrown.
	 */
	synchronized protected void clientException(ConnectionToClient client, Throwable exception) {
		clientDisconnected(client);
	}

	/**
	 * when the server is started this method will activate
	 */
	protected void serverStarted() {
		MainServerController.instance.add_Line("Server listening for connections on port " + getPort());
	}

	/**
	 * when the server is stopped this method will activate
	 */
	protected void serverStopped() {
		MainServerController.instance.add_Line("Server has stopped listening for connections.");
	}
}