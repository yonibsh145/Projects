package server;

import java.io.IOException;
import java.util.Optional;
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import server.common.EchoServer;
import server.common.controllers.logic_controllers.AnalyticSystem;
import server.common.controllers.logic_controllers.FuelReservesManager;

/**
 * this class is the main gui that runs. it hold the server side and can display
 * actions within its gui
 * 
 * @author henco
 * @version 1.0
 */
public class MainServerGui extends Application {

	/**
	 * the defult port of the server if none is given
	 */
	final public static int DEFAULT_PORT = 5555;
	/**
	 * save an instance of the server
	 */
	public static EchoServer server;

	/**
	 * this method is what runs our fxml file, and shows our server application here
	 * is where we start running our sub systems
	 * 
	 * @param primaryStage stage that the application runs on
	 */
	@Override
	public void start(Stage primaryStage) {
		AnchorPane pane = null;
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/server/boundry/MainServerPrototypeForm.fxml"));
			pane = loader.load();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}

		Scene s = new Scene(pane);
		s.getStylesheets().add("/server/boundry/MainServer.css");
		primaryStage.setScene(s);
		primaryStage.setResizable(true);
		primaryStage.show();
		primaryStage.setTitle("MyFuel Main-Server");
		primaryStage.getIcons().add(new Image(this.getClass().getResource("/icons8-thin-client-40.png").toString()));
		primaryStage.getScene().getWindow().addEventFilter(WindowEvent.WINDOW_CLOSE_REQUEST, new EventHandler<Event>() {

			@Override
			public void handle(Event event) {
				Alert alert = new Alert(Alert.AlertType.WARNING);
				alert.getButtonTypes().remove(ButtonType.OK);
				alert.getButtonTypes().add(ButtonType.CANCEL);
				alert.getButtonTypes().add(ButtonType.YES);
				alert.setTitle("Quit application");
				alert.setContentText(String.format("Close Server?"));
				alert.initOwner(primaryStage);
				Optional<ButtonType> res = alert.showAndWait();

				if (res.isPresent()) {
					if (res.get().equals(ButtonType.CANCEL)) {
						event.consume();
					} else
						try {
							if (server != null) {
								server.close();
								FuelReservesManager.getInstance().closeSystem();
								AnalyticSystem.getInstance().closeSystem();
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
			}

		});
	}

	/**
	 * this is the main method of the class. here we run everything.
	 * 
	 * @param args of the main
	 */
	public static void main(String[] args) {
		launch(args);
	}
}