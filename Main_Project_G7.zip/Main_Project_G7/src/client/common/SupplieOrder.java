package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * an entity class for refuel order that the system makes for the station
 * manager
 * 
 * @author henco
 * @version 1.0
 */
public class SupplieOrder {

	private SimpleStringProperty date, comment, topic, status;
	private String supplier, fuelType, quantity;
	private Integer supplierEID;
	private int orderID;

	/**
	 * a simple constractor
	 * 
	 * @param fuelType    the fuel type that needs to be refueled
	 * @param date        the order was made by the system
	 * @param supplier    that the order is for
	 * @param status      of the order
	 * @param quantity    of the order
	 * @param orderID     of the order
	 * @param supplierEID the id of the supplier
	 * 
	 */
	public SupplieOrder(String fuelType, String date, String supplier, String status, Float quantity, Integer orderID,
			Integer supplierEID) {
		this.date = new SimpleStringProperty(date);
		this.topic = new SimpleStringProperty("Refuel From: \n" + supplier);
		this.status = new SimpleStringProperty(status);
		this.comment = new SimpleStringProperty("New Order To Refuel " + fuelType + "\nAmount Of: " + quantity);
		this.supplier = supplier;
		this.fuelType = fuelType;
		this.quantity = quantity.toString();
		this.orderID = orderID;
		this.supplierEID = supplierEID;
	}

	public Integer getSupplierEID() {
		return supplierEID;
	}

	/**
	 * get the ID of the order
	 * 
	 * @return order id
	 */
	public int getOrderID() {
		return orderID;
	}

	/**
	 * get the date of the order
	 * 
	 * @return date of the order
	 */
	public String getDate() {
		return date.getValue();
	}

	/**
	 * get the description of the order (message)
	 * 
	 * @return order details
	 */
	public String getComment() {
		return comment.getValue();
	}

	/**
	 * get the topic of the order (always refueling in this case)
	 * 
	 * @return order topic
	 */
	public String getTopic() {
		return topic.getValue();
	}

	/**
	 * get the status of the order
	 * 
	 * @return order status
	 */
	public String getStatus() {
		return status.getValue();
	}

	/**
	 * get the supplier name
	 * 
	 * @return supplier name
	 */
	public String getSupplier() {
		return supplier;
	}

	/**
	 * get the fuel that is ordered
	 * 
	 * @return fuel type
	 */
	public String getFuelType() {
		return fuelType;
	}

	/**
	 * get the amount of fuel that is requested the refill
	 * 
	 * @return fuel amount
	 */
	public String getQuantity() {
		return quantity;
	}

}
