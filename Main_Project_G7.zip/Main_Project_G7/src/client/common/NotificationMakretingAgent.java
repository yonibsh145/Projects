package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * This class is for describe the notification for add to table
 * 
 * @author Yogev
 * @version 0.99
 */
public class NotificationMakretingAgent {

	private SimpleStringProperty name, date, description;
	private Integer userID, notificationID;

	/**
	 * Constructor for the notification of the marketing agent
	 * 
	 * @param name           of the notification
	 * @param date           that notification was made
	 * @param userID         that the notification belongs too
	 * @param description    the message content
	 * @param notificationID its id
	 */
	public NotificationMakretingAgent(String name, String date, Integer userID, String description,
			Integer notificationID) {
		this.name = new SimpleStringProperty(name);
		this.date = new SimpleStringProperty(date);
		this.userID = userID;
		this.description = new SimpleStringProperty(description);
		this.notificationID = notificationID;
	}

	/**
	 * name of the notification getter
	 * 
	 * @return the name of the notification
	 */
	public String getName() {
		return name.getValue();
	}

	/**
	 * date of the notification getter
	 * 
	 * @return the date of the notification
	 */
	public String getDate() {
		return date.getValue();
	}

	/**
	 * description of the notification getter
	 * 
	 * @return the description of the notification
	 */
	public String getDescription() {
		return description.getValue();
	}

	/**
	 * user ID getter
	 * 
	 * @return the ID of the user
	 */
	public Integer getUserID() {
		return userID;
	}

	/**
	 * notification ID getter
	 * 
	 * @return the notification specific ID
	 */
	public Integer getNotificationID() {
		return notificationID;
	}
}
