package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * This class is responsible for holding information for one row in the table
 * 
 * @author Yogev
 * @version 0.99
 */
public class Customer {

	private SimpleStringProperty email, customerName;
	private String firstName, lastName;
	private Integer id, userID, expMonth, expYear, cvv;
	private SimpleStringProperty customerType;
	private Long credit;

	/**
	 * Constructor of the customer for the table for private customer
	 * 
	 * @param first_name of the customer
	 * @param last_name of the customer
	 * @param id of the customer
	 * @param email of the customer
	 * @param credit,    credit card number
	 * @param userID     , the ID of the user
	 * @param expMonth experation month of his credit card
	 * @param expYear experation year of his credit card
	 * @param cvv,       3 digits behind the card
	 */
	public Customer(String first_name, String last_name, Integer id, String email, Long credit, Integer userID,
			Integer expMonth, Integer expYear, Integer cvv) {

		this.customerName = new SimpleStringProperty(first_name + " " + last_name);
		this.id = id;
		this.email = new SimpleStringProperty(email);
		this.credit = credit;
		this.userID = userID;
		this.expMonth = expMonth;
		this.expYear = expYear;
		this.cvv = cvv;
		this.customerType = new SimpleStringProperty("Private");
		this.firstName = first_name;
		this.lastName = last_name;
	}

	/**
	 * Constructor of the customer for the table for company customer
	 * 
	 * @param companyName the name of the company
	 * @param id	of the company
	 * @param email 	of the company
	 * @param credit     credit card number
	 * @param userID       the ID of the user
	 * @param expMonth  experation month of the customers credit
	 * @param expYear	experation year of the customers credit
	 * @param cvv        3 digits behind the card
	 */
	public Customer(String companyName, Integer id, String email, Long credit, Integer userID, Integer expMonth,
			Integer expYear, Integer cvv) {

		this.customerName = new SimpleStringProperty(companyName);
		this.id = id;
		this.email = new SimpleStringProperty(email);
		this.credit = credit;
		this.userID = userID;
		this.expMonth = expMonth;
		this.expYear = expYear;
		this.cvv = cvv;
		this.customerType = new SimpleStringProperty("Company");
	}

	/**
	 * email getter
	 * 
	 * @return the email
	 */
	public String getEmail() {
		return email.getValue();
	}

	/**
	 * company and private getter
	 * 
	 * @return the private or company name
	 */
	public String getCustomerName() {
		return customerName.getValue();
	}

	/**
	 * first name getter
	 * 
	 * @return the first name of private customer
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * last name getter
	 * 
	 * @return the first name of private customer
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * id getter
	 * 
	 * @return the id of the customer
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * credit card number getter only 4 last digits
	 * 
	 * @return the last 4 digits of the credit card
	 */
	public Integer getCredit() {
		return (int) (credit % 10000);
	}

	/**
	 * user id getter
	 * 
	 * @return the id of the user
	 */
	public Integer getUserID() {
		return userID;
	}

	/**
	 * exp. month getter
	 * 
	 * @return the exp. month of the credit card
	 */
	public Integer getExpMonth() {
		return expMonth;
	}

	/**
	 * exp. year getter
	 * 
	 * @return the exp. year of the credit card
	 */
	public Integer getExpYear() {
		return expYear;
	}

	/**
	 * CVV 3 digits getter
	 * 
	 * @return the CVV 3 digits of credit card
	 */
	public Integer getCvv() {
		return cvv;
	}

	/**
	 * "private"/ "company" type getter
	 * 
	 * @return "private"/ "company" String
	 */
	public String getCustomerType() {
		return customerType.getValue();
	}

	/**
	 * full credit card number getter
	 * 
	 * @return the full credit card number
	 */
	public Long getFullCredit() {
		return credit;
	}

}