package client.common;

/**
 * entity class that is used for filling up the details table of the
 * characterization report. an instance hold information for each customer
 * 
 * @author henco
 * @version 1.0
 */
public class CharacterizationInfo {

	private Long id, sonol, paz, delek, nrg, total, ten, dor;

	/**
	 * simple constractor
	 * 
	 * @param id    of a customer
	 * @param sonol amount of purchases in sonol company
	 * @param paz   amount of purchases in paz company
	 * @param delek amount of purchases in delek company
	 * @param nrg   amount of purchases in nrg company
	 * @param total total amount of purchases for a customer
	 * @param ten   amount of purchases in ten company
	 * @param dor   amount of purchases in dor alon company
	 */
	public CharacterizationInfo(Long id, Long sonol, Long paz, Long delek, Long nrg, Long total, Long ten, Long dor) {
		super();
		this.id = id;
		this.sonol = sonol;
		this.paz = paz;
		this.delek = delek;
		this.nrg = nrg;
		this.total = total;
		this.ten = ten;
		this.dor = dor;
	}

	/**
	 * getter for id
	 * 
	 * @return id of customer
	 */
	public Long getId() {
		return id;
	}

	/**
	 * getter of sonol purchases
	 * 
	 * @return amount of purchases in sonol company
	 */
	public Long getSonol() {
		return sonol;
	}

	/**
	 * getter of paz purchases
	 * 
	 * @return amount of purchases in paz company
	 */
	public Long getPaz() {
		return paz;
	}

	/**
	 * getter of delek purchases
	 * 
	 * @return amount of purchases in delek company
	 */
	public Long getDelek() {
		return delek;
	}

	/**
	 * getter of nrg purchases
	 * 
	 * @return amount of purchases in n.r.g company
	 */
	public Long getNrg() {
		return nrg;
	}

	/**
	 * getter of the total purchases
	 * 
	 * @return amount of tota purchases of the customer
	 */
	public Long getTotal() {
		return total;
	}

	/**
	 * getter of ten purchases
	 * 
	 * @return amount of purchases in ten company
	 */
	public Long getTen() {
		return ten;
	}

	/**
	 * getter of dor alon purchases
	 * 
	 * @return amount of purchases in dor alon company
	 */
	public Long getDor() {
		return dor;
	}

}
