package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * This class is for describe sale pattern for add to table
 * 
 * @author Yogev
 * @version 0.99
 */
public class SalePattern {
	private Integer gasStationTag, salePatternTag;
	private SimpleStringProperty name, description, fuelType, status, endHour, startHour;
	private Float discount;

	/**
	 * Constructor for sale pattern
	 * 
	 * @param name,           sale pattern name
	 * @param fuelType that the sale will be on
	 * @param startHour,      start hour of the sale
	 * @param endHour,        end hour of the sale
	 * @param discount present of the sale
	 * @param salePatternTag, ID of the sale
	 * @param status          , "active" or "un-active"
	 * @param gasStationTag   , ID of the station
	 * @param description	of the sale
	 */
	public SalePattern(String name, String fuelType, String startHour, String endHour, Float discount,
			Integer salePatternTag, String status, Integer gasStationTag, String description) {
		this.gasStationTag = gasStationTag;
		this.fuelType = new SimpleStringProperty(fuelType);
		this.salePatternTag = salePatternTag;
		this.startHour = new SimpleStringProperty(startHour);
		this.endHour = new SimpleStringProperty(endHour);
		this.discount = discount;
		this.name = new SimpleStringProperty(name);
		this.description = new SimpleStringProperty(description);
		this.status = new SimpleStringProperty(status);
	}

	/**
	 * status getter
	 * 
	 * @return the status of the sale
	 */
	public String getStatus() {
		return status.getValue();
	}

	/**
	 * sale pattern's name getter
	 * 
	 * @return the name of the sale pattern
	 */
	public String getName() {
		return name.getValue();
	}

	/**
	 * description getter
	 * 
	 * @return the description of the sale pattern
	 */
	public String getDescription() {
		return description.getValue();
	}

	/**
	 * gas station tag getter
	 * 
	 * @return the gas station tag number
	 */
	public Integer getGasStationTag() {
		return gasStationTag;
	}

	/**
	 * fuel type getter
	 * 
	 * @return the fuel type by String
	 */
	public String getFuelType() {
		return fuelType.getValue();
	}

	/**
	 * sale pattern tag (ID) getter
	 * 
	 * @return the sale pattern tag number
	 */
	public Integer getSalePatternTag() {
		return salePatternTag;
	}

	/**
	 * start hour getter
	 * 
	 * @return the start hour by specific shape "HH:MM"
	 */
	public String getStartHour() {
		Integer hour = new Integer(startHour.getValue());
		StringBuilder sb = new StringBuilder("");
		sb.append(hour / 100);
		sb.append(":");
		if (hour % 100 == 0) {
			sb.append("00");
		} else {
			sb.append(hour % 100);
		}
		return sb.toString();
	}

	/**
	 * end hour getter
	 * 
	 * @return the end hour by specific shape "HH:MM"
	 */
	public String getEndHour() {
		Integer hour = new Integer(endHour.getValue());
		StringBuilder sb = new StringBuilder("");
		sb.append(hour / 100);
		sb.append(":");
		if (hour % 100 == 0) {
			sb.append("00");
		} else {
			sb.append(hour % 100);
		}
		return sb.toString();
	}

	/**
	 * discount getter
	 * 
	 * @return the discount of the sale pattern
	 */
	public Float getDiscount() {
		return discount;
	}

}
