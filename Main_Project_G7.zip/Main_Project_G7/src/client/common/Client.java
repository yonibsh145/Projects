package client.common;

import java.io.*;
import ocsf.client.*;
import client.MainClientGUI;
import javafx.application.Platform;
import message_info.*;

/**
 * 
 * @author henco
 * @version 1.0
 */
public class Client extends AbstractClient {

	/**
	 * this class is the client side of the software
	 * 
	 * @param host gets the host location
	 * @param port defult port 5555
	 * @throws IOException when unable to connect
	 */

	public Client(String host, int port) throws IOException {
		super(host, port);
		openConnection(); // connect to a server here
	}

	/**
	 * when a message is recived from the server, this method will activate
	 * 
	 * @param msg gets the message that the server sent
	 */
	public void handleMessageFromServer(Object msg) {
		Message message = (Message) msg;
		MessageHandlerClient.HandleMessage(message); // sends the message to the messageHandler
	} // to let is handle all of the actions

	/**
	 * when we want to send a message to the server
	 * 
	 * @param message that the client sends to the server
	 */
	public void handleMessageFromClientUI(Object message) {
		try { // we will activate this method
			sendToServer(message);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * when we want to disconnect from a sever we
	 */
	public void quit() {
		try { // activate this method
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}

	/**
	 * this method handles whenever there is an exeption in the client.
	 * 
	 * @param exception that the client enconters.
	 */
	protected void connectionException(Exception exception) {

		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				MainClientGUI.exit();
			}
		});
	}

}
