package client.common;

/**
 * entity class that is used for filling up the details table of the comments
 * report. an instance hold information for each customer
 * 
 * @author henco
 * @version 1.0
 */
public class CommentsInfo {

	private Integer id;
	private Double sum;

	/**
	 * simple constractor
	 * 
	 * @param id  of the customer
	 * @param sum total amount of income from the customer
	 */
	public CommentsInfo(Integer id, Double sum) {
		this.id = id;
		this.sum = sum;
	}

	/**
	 * getter of the user's id
	 * 
	 * @return customer's id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * getter of total amount of income from the customer for this report
	 * 
	 * @return sum of purchases price
	 */
	public Double getSum() {
		return sum;
	}
}
