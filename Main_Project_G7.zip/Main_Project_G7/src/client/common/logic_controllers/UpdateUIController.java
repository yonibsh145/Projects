package client.common.logic_controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import client.common.CharacterizationInfo;
import client.common.CommentsInfo;
import client.common.controllers.MarketingManagerReportsController;
import client.common.controllers.StationManagerReportsController;
import client.common.controllers.StationManagerStationController;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;

/**
 * a class that helps the controllers to create reports from the information
 * matrix recived from the server
 * 
 * @author henco
 * @version 1.0
 */
public class UpdateUIController {

	/**
	 * this method initialize the reserves information in a station manager
	 * "station" page
	 * 
	 * @param table with all of the relevent reserves info
	 */
	public static void initializeStationManager(ArrayList<ArrayList<Object>> table) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				StationManagerStationController.instance.setUpFuel_return(table);
			}
		});
	}

	/**
	 * this method gets a matrix with information to create a Reserve-Report it
	 * handles all of the information in order to create an arrayList of string with
	 * rows of the report, to the controller will have an easer job to print the
	 * report
	 *
	 * @param table with report information
	 */
	public static void add_info_to_listview_station_manager_reserves(ArrayList<ArrayList<Object>> table) {
		ArrayList<String> report = new ArrayList<>();
		report.add("Reserves Report:");
		report.add("");
		report.add("Station Number : " + StationManagerReportsController.station_tag_number);
		report.add("");
		report.add("Station Name : " + table.get(0).get(8));
		report.add("");
		for (ArrayList<Object> arrayList : table) {
			report.add("Reserve Number: " + arrayList.get(6) + " Fuel Type: " + arrayList.get(7));
			report.add("Max Quantity In Reserve: " + arrayList.get(4) + " Minimum Threshold: "
					+ ((Float) arrayList.get(3)));
			report.add("Price For Liter: " + arrayList.get(1) + " Current Amount Of Fuel: " + arrayList.get(2));
			report.add("");

		}
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				StationManagerReportsController.instance.reserves_report_returned(report);
			}
		});
	}

	/**
	 * this method gets a matrix with information to create a Income-Report it
	 * handles all of the information in order to create an arrayList of string with
	 * rows of the report, to the controller will have an easer job to print the
	 * report
	 *
	 * @param table with report information
	 */
	public static void add_info_to_listview_station_manager_income(ArrayList<ArrayList<Object>> table) {

		ArrayList<String> report = new ArrayList<>();
		if (table != null) {
			String timeStampMonth = new SimpleDateFormat("MM").format(Calendar.getInstance().getTime());
			String timeStampYear = new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime());
			Integer currentMonth = new Integer(timeStampMonth.toString());
			double sum = 0;
			int count = 3;
			if (currentMonth % 3 != 0) {
				currentMonth = (currentMonth / 3);
			} else {
				currentMonth = ((currentMonth / 3) - 1);
			}
			currentMonth++;
			report.add("Income Report: Quarter #" + currentMonth + " Year: " + timeStampYear);
			report.add("");
			report.add("Station Number : " + StationManagerReportsController.station_tag_number);
			report.add("");
			report.add("Station Name : " + table.get(0).get(4));
			report.add("");
			for (ArrayList<Object> row : table) {
				report.add("Fuel Type: " + row.get(0));
				report.add("Total Income: " + String.format("%.02f", row.get(1)) + " Total Purchases: " + row.get(2));
				report.add("");
				sum += (Double) row.get(1);
			}
			report.add("Monthly Avarage: " + String.format("%.02f", (sum / count)));
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					StationManagerReportsController.instance.income_report_returned(report, true);
				}
			});
		} else {
			String timeStampMonth = new SimpleDateFormat("MM").format(Calendar.getInstance().getTime());
			String timeStampYear = new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime());
			Integer currentMonth = new Integer(timeStampMonth.toString());
			if (currentMonth % 3 != 0) {
				currentMonth = (currentMonth / 3);
			} else {
				currentMonth = ((currentMonth / 3) - 1);
			}
			currentMonth++;
			report.add("Income Report: Quarter #" + currentMonth + " Year: " + timeStampYear);
			report.add("");
			report.add("Station Number : " + StationManagerReportsController.station_tag_number);
			report.add("");

			report.add("Fuel Type: Motor");
			report.add("Total Income: 0.0 Total Purchases: 0");
			report.add("");
			report.add("Fuel Type: Benzin 95");
			report.add("Total Income: 0.0 Total Purchases: 0");
			report.add("");
			report.add("Fuel Type: Soler");
			report.add("Total Income: 0.0 Total Purchases: 0");
			report.add("");

			report.add("Monthly Avarage: 0.0");
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					StationManagerReportsController.instance.income_report_returned(report, false);
				}
			});
		}
	}

	/**
	 * this method gets a matrix with information to create a Purchases Report it
	 * handles all of the information in order to create an arrayList of string with
	 * rows of the report, to the controller will have an easer job to print the
	 * report
	 *
	 * @param purchas_report with report information
	 */
	public static void add_info_to_listview_station_manager_purchases(ArrayList<ArrayList<Object>> purchas_report) {
		ArrayList<String> report = new ArrayList<>();
		if (purchas_report != null) {
			report.add("Purchases Report:");
			report.add("");
			report.add("Station Number : " + StationManagerReportsController.station_tag_number);
			report.add("");
			report.add("Station Name : " + purchas_report.get(0).get(4));
			report.add("");
			for (ArrayList<Object> arrayList : purchas_report) {
				report.add("Fuel Type: " + arrayList.get(0));
				report.add("Amount Of Purchases: " + arrayList.get(3));
				report.add("Money Earned: " + String.format("%.02f", arrayList.get(1)));
				report.add("Total Amount Of Fuel Sold: " + String.format("%.02f", arrayList.get(2)));
				report.add("");
			}
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					StationManagerReportsController.instance.purchases_report_returned(report, true);
				}
			});
		} else {
			report.add("Purchases Report:");
			report.add("");
			report.add("Station Number : " + StationManagerReportsController.station_tag_number);
			report.add("");
			report.add("Fuel Type: Motor");
			report.add("Amount Of Purchases: 0");
			report.add("Money Earned: 0");
			report.add("Total Amount Of Fuel Sold: 0");
			report.add("");
			report.add("Fuel Type: Diesel 95");
			report.add("Amount Of Purchases: 0");
			report.add("Money Earned: 0");
			report.add("Total Amount Of Fuel Sold: 0");
			report.add("");
			report.add("Fuel Type: Soler");
			report.add("Amount Of Purchases: 0");
			report.add("Money Earned: 0");
			report.add("Total Amount Of Fuel Sold: 0");
			report.add("");
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					StationManagerReportsController.instance.purchases_report_returned(report, false);
				}
			});
		}
	}

	/**
	 * this method get the details of periodic characterization report and add it to
	 * the report. the report will be sorted by the amount of purcahses that each
	 * customer makes
	 * 
	 * @param table get the table details from DB for initialize
	 */
	public static void add_info_to_listview_marketing_manager_periodic_characterization(
			ArrayList<ArrayList<Object>> table) {

		class Pairs implements Comparable<Object> {
			String id;
			Long count;

			public Pairs(String id) {
				this.id = id;
				this.count = new Long(0);
			}

			public String getID() {
				return id;
			}

			public Long getCount() {
				return count;
			}

			public void addToCount(Long add) {
				count += add;
			}

			@Override
			public int compareTo(Object arg0) {
				if (count < (Long) arg0)
					return -1;
				if (count > (Long) arg0)
					return 1;
				return 0;
			}
		}

		ArrayList<String> report = new ArrayList<>();
		HashMap<String, Number> dia = new HashMap<String, Number>();
		if (table != null) {
			XYChart.Series<String, Number> series = new Series<String, Number>();
			HashMap<String, Set<String>> customerId = new HashMap<String, Set<String>>();
			HashMap<String, Pairs> order = new HashMap<String, Pairs>();
			HashMap<String, HashMap<String, Long>> table_char = new HashMap<String, HashMap<String, Long>>();
			report.add("Periodic Characterization Report:");
			for (ArrayList<Object> arrayList : table) {
				if (!customerId.containsKey((String) arrayList.get(0))) {
					customerId.put((String) arrayList.get(0), new HashSet<String>());
					order.put((String) arrayList.get(0), new Pairs((String) arrayList.get(0)));
					table_char.put((String) arrayList.get(0), new HashMap<String, Long>());
					table_char.get((String) arrayList.get(0)).put("Sonol", new Long(0));
					table_char.get((String) arrayList.get(0)).put("Paz", new Long(0));
					table_char.get((String) arrayList.get(0)).put("Delek", new Long(0));
					table_char.get((String) arrayList.get(0)).put("Ten", new Long(0));
					table_char.get((String) arrayList.get(0)).put("N.R.G", new Long(0));
					table_char.get((String) arrayList.get(0)).put("Dor Alon", new Long(0));
				}
			}
			dia.put((String) table.get(0).get(2), (long) 0);
			series.setName("Purchases");
			Long cnt = new Long(0);
			String temp = (String) table.get(0).get(2);
			for (ArrayList<Object> arrayList : table) {
				customerId.get((String) arrayList.get(0))
						.add(" Amount of purchases: " + arrayList.get(1) + " Company name: " + arrayList.get(2));
				order.get((String) arrayList.get(0)).addToCount((Long) arrayList.get(1));
				table_char.get((String) arrayList.get(0)).put((String) arrayList.get(2), (Long) arrayList.get(1));
				temp = (String) arrayList.get(2);
				if (!dia.containsKey(temp)) {
					dia.put(temp, (long) 0);
				}
				cnt = (Long) dia.get(temp);
				cnt += (Long) arrayList.get(1);
				dia.put(temp, cnt);
			}
			ObservableList<CharacterizationInfo> info = FXCollections.observableArrayList();
			for (String key : table_char.keySet()) {
				Long total = new Long(0);
				for (String company : table_char.get(key).keySet()) {
					total += table_char.get(key).get(company);
				}
				info.add(new CharacterizationInfo(new Long(key), table_char.get(key).get("Sonol"),
						table_char.get(key).get("Paz"), table_char.get(key).get("Delek"),
						table_char.get(key).get("N.R.G"), total, table_char.get(key).get("Ten"),
						table_char.get(key).get("Dor Alon")));

			}
			for (String key : dia.keySet())
				series.getData().add(new Data<String, Number>(key, dia.get(key)));
			MarketingManagerReportsController.instance.char_report = info;
			List<Pairs> sort = new ArrayList<>(order.values());

			Collections.sort(sort, Comparator.comparing(Pairs::getCount));
			Collections.reverse(sort);
			for (Pairs Id : sort) {
				report.add("");
				report.add("Customer ID: " + Id.getID());
				for (String object : customerId.get(Id.getID())) {
					report.add(object);

				}

			}
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					MarketingManagerReportsController.instance.setdiagram(series);
					MarketingManagerReportsController.instance.periodic_characterization_report_returned(report);
				}
			});
		} else {
			MarketingManagerReportsController.instance.char_report = null;
		}
	}

	/**
	 * this method get the details of comments report for sale pattern report and
	 * add it to the report
	 * 
	 * @param table, get the table details from DB for initialize
	 */
	public static void add_info_to_listview_marketing_manager_comments(ArrayList<ArrayList<Object>> table) {
		int count = 0;
		double sum = 0;
		String temp;
		ArrayList<String> report = new ArrayList<>();
		HashMap<Integer, Double> comments = new HashMap<>();
		if (table != null) {
			report.add("Comments Report:");
			report.add("");
			report.add("sale patrren name : " + MarketingManagerReportsController.sale_PatrrenName);
			report.add("");
			for (ArrayList<Object> arrayList : table) {
				temp = String.format("%.02f", arrayList.get(1));
				report.add("Customer ID: " + arrayList.get(0) + " Total spending: " + temp);
				comments.put(new Integer(arrayList.get(0).toString()), new Double(temp));
				report.add("");
				count++;
				sum += (Double) arrayList.get(1);
			}
			temp = String.format("%.02f", sum);
			report.add("Total customers purchased in the sale : " + count);
			report.add("Total earning in the sale : " + temp);
			ObservableList<CommentsInfo> list = FXCollections.observableArrayList();
			for (Integer key : comments.keySet()) {
				list.add(new CommentsInfo(key, comments.get(key)));
			}
			MarketingManagerReportsController.instance.comment_report = list;
		} else {
			MarketingManagerReportsController.instance.comment_report = null;
		}
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				MarketingManagerReportsController.instance.comments_report_returned(report);

			}
		});
	}
}
