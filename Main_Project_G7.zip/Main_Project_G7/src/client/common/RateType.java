package client.common;
/**
 * this class helpful for Discount page and discount add page
 * @author Yehonatan
 * @version 0.99
 *
 */
public enum RateType {
	/**
	 * the rate types
	 */
	Casualfuel,RoutineMonthlyFuelSingleCar,RoutineMonthlyFuelSomeCars,FullMonthlyFuelSingleCar;
	public static int getRateType(String num) {
		switch (num) {
		case "Casual fuel":
			return 1;
		case "Routine monthly fuel - single car":
			return 2;
		case "Routine monthly fuel - some cars":
			return 3;
		case "Full monthly fuel - single car":
			return 4;
		default:
			break;
		}
		try {
			throw new Exception("Rate type error");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
}
