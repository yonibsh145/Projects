package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * This class holds the parameters of the table that displayed on the supplier order screen.
 * Each instance of the class reflect to a row in the table
 * 
 * @author yarin
 * @version 0.99
 *
 */

public class AcceptedOrders 
{
	private SimpleStringProperty date,status,fuelType;
	private Integer orderTag, gasStation;
	private Float quantity;
	
	/**
	 * 
	 * @param date			string parameter that holds the date of the order
	 * @param orderTag		integer parameter that holds the p.key of the order, the id.
	 * @param gasStation	integer parameter that holds the number that describe the specific station
	 * @param quantity		float parameter that holds the quantity of fuel that required
	 * @param fuelType		string parameter that holds the number that describe the type of fuel
	 * @param status		string parameter that holds the status of the order
	 */
	public AcceptedOrders(String date, Integer orderTag, Integer gasStation,Float quantity,String fuelType, String status) {
		this.date = new SimpleStringProperty (date);
		this.status = new SimpleStringProperty(status);
		this.orderTag = orderTag;
		this.gasStation = gasStation;
		this.fuelType= new SimpleStringProperty(fuelType);
		this.quantity = quantity;
	}

/**
 * this method return the order date
 * @return order date
 */
	public String getDate() {
		return date.getValue();
	}
	/**
	 * this method return the status
	 * @return status
	 */
	public String getStatus() {
		return status.getValue();
	}

	/**
	 * this method return the order tag
	 * @return order tag
	 */
	public Integer getOrderTag() {
		return orderTag;
	}

	/**
	 * this method return the gas station
	 * @return gas station
	 */
	public Integer getGasStation() {
		return gasStation;
	}

	/**
	 * this method return the quantity
	 * @return quantity
	 */
	public Float getQuantity() {
		return quantity;
	}
	/**
	 * this method return the fuel type
	 * @return fuel type
	 */
	public String getFuelType() {
		return fuelType.getValue();
	}




	
	
	
		
	
}
