package message_info;

/**
 * this class is a enum for returned message types
 * 
 * @author henco
 * @version 1.0
 */
public enum ReturnMessageType {
	UPDATE_FAILED, UPDATE_SUCCESSFUL, RETURNED_INFO, RETURNED_INFO_FAILED, LOGIN_FAILED, LOGIN_SUCCESSFUL,
	LOGOUT_FAILED, LOGOUT_SUCCESSFUL, LOGIN_REQUEST_SUCCESSFUL, LOGIN_REQUEST_FAILED;
}
